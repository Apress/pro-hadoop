
document.write('<p class="menu_header">SLF4J-related buzz</p>');

document.write('<p class="rm small"><a href="http://blog.emmanuelbernard.com/2007/08/innovation-in-log-space-yawn.html">Innovation in the Log space</a>');
document.write('</p>');



document.write('<p class="rm small"><a href="http://thecodist.com/fiche/thecodist/article/the-open-source-frameworks-i-use">Frameworks I use</a>');
document.write('</p>');

document.write('<p class="rm small"><a href="http://day-to-day-stuff.blogspot.com/2007/07/no-more-commons-logging.html">VERSION 99.0</a>');
document.write('</p>');

document.write('<p class="rm small"><a href="http://blog.lukas-vlcek.com/2007/05/jakarta-commons-logging-and-slf4j.html">JCL and SLF4J</a>');
document.write('</p>');


document.write('<p class="rm small"><a href="http://hohonuuli.blogspot.com/2007/04/sl4j-code-template-for-netbeans-i-use.html">Code Template for Netbeans</a>');
document.write('</p>');


document.write('<p class="rm small"><a href="http://www.brokenbuild.com/blog/2007/02/21/maven2-cargo-and-deploying-to-jetty-6-with-commons-logging/">Maven2, Cargo etc.</a>');
document.write('</p>');

document.write('<p class="rm small"><a href="http://blog.organicelement.com/2006/12/21/commons-logging-classloader-woes/">JCL woes</a>');
document.write('</p>');

document.write('<p class="rm small"><a href="http://www.brodwall.com/johannes/blog/2007/01/20/article-ready-for-edit-embedded-web-integration-testing-with-jetty/">Embedded Web Integration</a>');
document.write('</p>');


document.write('<p class="rm small"><a href="http://www.fernandoribeiro.eti.br/2006/05/how-to-use-slf4j-with-log4j.html">How to Use SLF4J with log4j</a>');
document.write('</p>');

document.write('<p class="rm small"><a href="http://www.codesmell.de/blog/2006/03/cool-down-hot-deployment.html">Cool down the hot deployment</a>');
document.write('</p>');

document.write('<p class="rm small"><a href="http://sbtourist.blogspot.com/2007/01/join-us-be-commons-logging-free.html">Join us: Be Commons-Logging Free!</a>');
document.write('</p>');
