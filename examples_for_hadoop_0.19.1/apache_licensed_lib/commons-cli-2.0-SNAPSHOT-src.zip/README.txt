Jakarta Commons CLI
===================

Welcome to the CLI component of the Jakarta Commons project.

The information in this file is relevant if you have
downloaded a CLI source distribution.

For testing the project, you will need JUnit (if you use
maven this will be automatically installed and configured
for you):

  http://www.junit.org/

There are two ways to build CLI, either with ant or maven.

Ant can be found here :

  http://jakarta.apache.org/ant

and to build and test the system use:

  ant dist

Maven can be found here :

  http://maven.apache.org

and to build and test the system use:

  maven jar:jar

The system will build and test itself.

For complete documentation and to create a local copy of the
CLI project website, type:

  maven site

Good luck!

-The CLI Team
